-- Logistics Data Warehouse Star Schema
CREATE TABLE Dim_Date (
    Date_Key INTEGER PRIMARY KEY,
    Booking_Date TEXT,
    Year INTEGER,
    Quarter TEXT,
    Month INTEGER,
    Day INTEGER,
    Weekday TEXT
);

CREATE TABLE Dim_Customer (
    Customer_Key INTEGER PRIMARY KEY,
    Customer_ID TEXT,
    Customer_Type TEXT,
    Region TEXT,
    City TEXT
);

CREATE TABLE Dim_Route (
    Route_Key INTEGER PRIMARY KEY,
    Route_ID TEXT,
    Origin_Region TEXT,
    Destination_Region TEXT,
    Distance_Category TEXT
);

CREATE TABLE Dim_Vehicle (
    Vehicle_Key INTEGER PRIMARY KEY,
    Vehicle_ID TEXT,
    Vehicle_Type TEXT,
    Capacity_KG REAL,
    Fuel_Type TEXT
);

CREATE TABLE Dim_Driver (
    Driver_Key INTEGER PRIMARY KEY,
    Driver_ID TEXT,
    Experience_Years INTEGER,
    Performance_Rating REAL
);

CREATE TABLE Dim_Warehouse (
    Warehouse_Key INTEGER PRIMARY KEY,
    Warehouse_ID TEXT,
    Warehouse_Name TEXT,
    City TEXT,
    Region TEXT
);

CREATE TABLE Dim_Location (
    Location_Key INTEGER PRIMARY KEY,
    Latitude REAL,
    Longitude REAL,
    Origin_Region TEXT,
    Destination_Region TEXT
);

CREATE TABLE Fact_Shipment (
    Shipment_Key INTEGER PRIMARY KEY,
    Shipment_ID TEXT,
    Date_Key INTEGER,
    Customer_Key INTEGER,
    Route_Key INTEGER,
    Vehicle_Key INTEGER,
    Driver_Key INTEGER,
    Warehouse_Key INTEGER,
    Location_Key INTEGER,
    Shipment_Count INTEGER,
    Distance REAL,
    Delivery_Time REAL,
    Expected_Time REAL,
    Delay_Hours REAL,
    Transportation_Cost REAL,
    Delivery_Status TEXT
);
