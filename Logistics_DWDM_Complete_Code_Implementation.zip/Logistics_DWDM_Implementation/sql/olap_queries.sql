-- 1. ROLL-UP: Monthly shipment totals
SELECT d.Year,d.Month,SUM(f.Shipment_Count) AS Shipment_Count,
AVG(f.Delay_Hours) AS Avg_Delay
FROM Fact_Shipment f JOIN Dim_Date d ON f.Date_Key=d.Date_Key
GROUP BY d.Year,d.Month;

-- 2. DRILL-DOWN: Daily detail
SELECT d.Year,d.Quarter,d.Month,d.Day,SUM(f.Shipment_Count) AS Shipment_Count
FROM Fact_Shipment f JOIN Dim_Date d ON f.Date_Key=d.Date_Key
GROUP BY d.Year,d.Quarter,d.Month,d.Day;

-- 3. SLICE: One year
SELECT c.Region,COUNT(*) AS Shipment_Count,AVG(f.Delay_Hours) AS Avg_Delay
FROM Fact_Shipment f
JOIN Dim_Date d ON f.Date_Key=d.Date_Key
JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
WHERE d.Year=2026
GROUP BY c.Region;

-- 4. DICE: Selected dimensions
SELECT c.Region,v.Vehicle_Type,COUNT(*) AS Shipment_Count,AVG(f.Delay_Hours) AS Avg_Delay
FROM Fact_Shipment f
JOIN Dim_Date d ON f.Date_Key=d.Date_Key
JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
JOIN Dim_Vehicle v ON f.Vehicle_Key=v.Vehicle_Key
WHERE d.Year=2026
AND c.Region IN ('South','East')
AND v.Vehicle_Type='Truck'
GROUP BY c.Region,v.Vehicle_Type;

-- 5. PIVOT source query
SELECT d.Month,c.Region,SUM(f.Shipment_Count) AS Shipment_Count
FROM Fact_Shipment f
JOIN Dim_Date d ON f.Date_Key=d.Date_Key
JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
GROUP BY d.Month,c.Region;
