# Logistics Data Warehouse and Data Mining System

## Project Title
Design a Logistics Data Warehouse and Data Mining System for Shipment Analysis,
Delivery Prediction, Route Clustering, Frequent Transportation Pattern Mining,
and Spatial Analytics.

## Features Implemented
1. Synthetic multi-source logistics data generation
2. ETL and data cleaning
3. Missing-value handling and duplicate removal
4. Data integration using common keys
5. SQLite Star Schema Data Warehouse
6. OLAP operations: Roll-up, Drill-down, Slice, Dice and Pivot
7. Classification models:
   - Decision Tree
   - Naive Bayes
   - Support Vector Machine
8. Model evaluation:
   - Accuracy
   - Precision
   - Recall
   - F1-score
   - Confusion Matrix
   - 10-fold Cross Validation
9. Route clustering using K-Means
10. Frequent transportation pattern mining using Apriori
11. Spatial analytics using latitude/longitude and density plots
12. Automatic graphs and result files

## Installation
```bash
pip install -r requirements.txt
```

## Run the Complete Project
```bash
python src/main.py
```

## Main Output Files
- data/processed/logistics_integrated.csv
- data/processed/logistics_warehouse.db
- outputs/results/model_comparison.csv
- outputs/results/confusion_matrix_*.csv
- outputs/results/route_clusters.csv
- outputs/results/association_rules.csv
- outputs/results/olap_results.txt
- outputs/graphs/model_comparison.png
- outputs/graphs/route_clusters.png
- outputs/graphs/spatial_shipments.png
- outputs/graphs/monthly_delivery_performance.png
- outputs/graphs/shipment_volume_by_region.png
