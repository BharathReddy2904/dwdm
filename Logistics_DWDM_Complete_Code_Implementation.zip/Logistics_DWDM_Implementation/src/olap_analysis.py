import sqlite3
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
DB = BASE/"data"/"processed"/"logistics_warehouse.db"
OUT = BASE/"outputs"/"results"
GRAPHS = BASE/"outputs"/"graphs"

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    GRAPHS.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)

    # Roll-up
    rollup = pd.read_sql_query("""
    SELECT d.Year, d.Month, SUM(f.Shipment_Count) Shipment_Count,
           AVG(f.Delay_Hours) Avg_Delay
    FROM Fact_Shipment f JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    GROUP BY d.Year,d.Month ORDER BY d.Year,d.Month
    """, con)

    # Drill-down
    drill = pd.read_sql_query("""
    SELECT d.Year,d.Quarter,d.Month,d.Day,SUM(f.Shipment_Count) Shipment_Count
    FROM Fact_Shipment f JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    GROUP BY d.Year,d.Quarter,d.Month,d.Day
    ORDER BY Shipment_Count DESC LIMIT 20
    """, con)

    # Slice
    slice_df = pd.read_sql_query("""
    SELECT c.Region, COUNT(*) Shipment_Count, AVG(f.Delay_Hours) Avg_Delay
    FROM Fact_Shipment f
    JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
    WHERE d.Year=2026
    GROUP BY c.Region
    """, con)

    # Dice
    dice = pd.read_sql_query("""
    SELECT c.Region,v.Vehicle_Type,COUNT(*) Shipment_Count,AVG(f.Delay_Hours) Avg_Delay
    FROM Fact_Shipment f
    JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
    JOIN Dim_Vehicle v ON f.Vehicle_Key=v.Vehicle_Key
    WHERE d.Year=2026 AND c.Region IN ('South','East') AND v.Vehicle_Type='Truck'
    GROUP BY c.Region,v.Vehicle_Type
    """, con)

    # Pivot
    pivot_source = pd.read_sql_query("""
    SELECT d.Month,c.Region,SUM(f.Shipment_Count) Shipment_Count
    FROM Fact_Shipment f
    JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
    GROUP BY d.Month,c.Region
    """, con)
    pivot = pivot_source.pivot_table(index="Month", columns="Region", values="Shipment_Count", aggfunc="sum", fill_value=0)

    rollup.to_csv(OUT/"olap_rollup.csv", index=False)
    drill.to_csv(OUT/"olap_drilldown.csv", index=False)
    slice_df.to_csv(OUT/"olap_slice.csv", index=False)
    dice.to_csv(OUT/"olap_dice.csv", index=False)
    pivot.to_csv(OUT/"olap_pivot.csv")

    with open(OUT/"olap_results.txt","w") as f:
        for name, x in [("ROLL-UP",rollup),("DRILL-DOWN",drill),("SLICE",slice_df),("DICE",dice),("PIVOT",pivot)]:
            f.write("\\n"+name+"\\n")
            f.write(x.to_string())
            f.write("\\n")

    # Graph 1
    region = pd.read_sql_query("""
    SELECT c.Region, COUNT(*) Shipment_Count
    FROM Fact_Shipment f JOIN Dim_Customer c ON f.Customer_Key=c.Customer_Key
    GROUP BY c.Region ORDER BY Shipment_Count DESC
    """, con)
    plt.figure(figsize=(8,5))
    plt.bar(region["Region"], region["Shipment_Count"])
    plt.title("Shipment Volume by Region")
    plt.xlabel("Region"); plt.ylabel("Shipment Count")
    plt.tight_layout()
    plt.savefig(GRAPHS/"shipment_volume_by_region.png", dpi=180)
    plt.close()

    # Graph 2
    monthly_status = pd.read_sql_query("""
    SELECT d.Month,f.Delivery_Status,COUNT(*) Count
    FROM Fact_Shipment f JOIN Dim_Date d ON f.Date_Key=d.Date_Key
    GROUP BY d.Month,f.Delivery_Status
    """, con)
    pivot2 = monthly_status.pivot(index="Month", columns="Delivery_Status", values="Count").fillna(0)
    plt.figure(figsize=(9,5))
    for col in pivot2.columns:
        plt.plot(pivot2.index, pivot2[col], marker="o", label=col)
    plt.title("Monthly Delivery Performance")
    plt.xlabel("Month"); plt.ylabel("Number of Shipments")
    plt.legend(); plt.tight_layout()
    plt.savefig(GRAPHS/"monthly_delivery_performance.png", dpi=180)
    plt.close()

    con.close()
    print("OLAP analysis and graphs completed.")

if __name__ == "__main__":
    main()
