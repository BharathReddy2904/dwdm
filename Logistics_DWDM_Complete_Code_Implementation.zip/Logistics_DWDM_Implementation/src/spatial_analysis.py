from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
DATA = BASE/"data"/"processed"/"logistics_integrated.csv"
OUT = BASE/"outputs"/"results"
GRAPHS = BASE/"outputs"/"graphs"

def main():
    OUT.mkdir(parents=True, exist_ok=True); GRAPHS.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA)

    plt.figure(figsize=(8,7))
    for status in ["On-Time","Delayed"]:
        x = df[df["Delivery_Status"]==status]
        plt.scatter(x["Longitude"], x["Latitude"], alpha=0.35, s=10, label=status)
    plt.title("Spatial Distribution of Shipments")
    plt.xlabel("Longitude"); plt.ylabel("Latitude")
    plt.legend(); plt.tight_layout()
    plt.savefig(GRAPHS/"spatial_shipments.png", dpi=180)
    plt.close()

    density = df.groupby(["Origin_Region","Destination_Region"]).agg(
        Shipment_Count=("Shipment_ID","count"),
        Average_Delay=("Delay_Hours","mean")
    ).reset_index().sort_values("Shipment_Count", ascending=False)
    density.to_csv(OUT/"spatial_route_density.csv", index=False)

    hotspots = df.groupby("Region").agg(
        Shipment_Count=("Shipment_ID","count"),
        Average_Delay=("Delay_Hours","mean"),
        Delayed_Shipments=("Delivery_Status", lambda x: (x=="Delayed").sum())
    ).reset_index().sort_values("Shipment_Count", ascending=False)
    hotspots.to_csv(OUT/"regional_spatial_hotspots.csv", index=False)
    print("Spatial analysis completed.")

if __name__ == "__main__":
    main()
