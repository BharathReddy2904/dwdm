import sqlite3
from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path(__file__).resolve().parents[1]
RAW = BASE/"data"/"raw"
PROCESSED = BASE/"data"/"processed"
PROCESSED.mkdir(parents=True, exist_ok=True)

def load_and_clean():
    shipment = pd.read_csv(RAW/"shipments.csv")
    gps = pd.read_csv(RAW/"gps.csv")
    customers = pd.read_csv(RAW/"customers.csv")
    vehicles = pd.read_csv(RAW/"vehicles.csv")
    drivers = pd.read_csv(RAW/"drivers.csv")
    warehouses = pd.read_csv(RAW/"warehouses.csv")

    before = len(shipment)
    shipment = shipment.drop_duplicates(subset=["Shipment_ID"], keep="first")

    for c in ["Distance_KM", "Weight_KG", "Warehouse_Processing_Hours",
              "Expected_Delivery_Hours", "Actual_Delivery_Hours", "Delay_Hours",
              "Transportation_Cost"]:
        shipment[c] = shipment[c].fillna(shipment[c].median())

    for c in ["Traffic_Level", "Weather_Condition"]:
        shipment[c] = shipment[c].fillna(shipment[c].mode()[0])

    shipment["Booking_Date"] = pd.to_datetime(shipment["Booking_Date"])
    shipment["Distance_Category"] = pd.cut(
        shipment["Distance_KM"], bins=[0,50,200,float("inf")],
        labels=["Short","Medium","Long"]
    ).astype(str)
    shipment["Weight_Category"] = pd.cut(
        shipment["Weight_KG"], bins=[0,5,20,float("inf")],
        labels=["Light","Medium","Heavy"]
    ).astype(str)
    shipment["Delay_Category"] = pd.cut(
        shipment["Delay_Hours"], bins=[-0.01,0,4,12,float("inf")],
        labels=["On-Time","Low Delay","Medium Delay","High Delay"]
    ).astype(str)

    # Integrate sources
    df = shipment.merge(customers, on="Customer_ID", how="left")
    df = df.merge(vehicles, on="Vehicle_ID", how="left")
    df = df.merge(drivers, on="Driver_ID", how="left")
    df = df.merge(warehouses, on="Warehouse_ID", how="left", suffixes=("", "_Warehouse"))
    gps = gps.drop_duplicates(subset=["Shipment_ID"], keep="first")
    df = df.merge(gps, on="Shipment_ID", how="left")

    # Validation
    df = df[df["Distance_KM"] > 0]
    df = df[df["Weight_KG"] > 0]
    df = df[df["Latitude"].between(-90,90)]
    df = df[df["Longitude"].between(-180,180)]

    df["Route_ID"] = df["Origin_Region"] + "_TO_" + df["Destination_Region"]
    df["Year"] = df["Booking_Date"].dt.year
    df["Quarter"] = "Q" + df["Booking_Date"].dt.quarter.astype(str)
    df["Month"] = df["Booking_Date"].dt.month
    df["Day"] = df["Booking_Date"].dt.day
    df["Weekday"] = df["Booking_Date"].dt.day_name()

    df.to_csv(PROCESSED/"logistics_integrated.csv", index=False)
    print("ETL complete.")
    print("Records before duplicate removal:", before)
    print("Records after cleaning:", len(df))
    return df

def build_sqlite_warehouse(df):
    db = PROCESSED/"logistics_warehouse.db"
    if db.exists():
        db.unlink()
    con = sqlite3.connect(db)

    dim_date = df[["Booking_Date","Year","Quarter","Month","Day","Weekday"]].drop_duplicates().copy()
    dim_date.insert(0, "Date_Key", range(1, len(dim_date)+1))
    dim_date["Booking_Date"] = dim_date["Booking_Date"].astype(str)

    dim_customer = df[["Customer_ID","Customer_Type","Region","City"]].drop_duplicates().copy()
    dim_customer.insert(0, "Customer_Key", range(1, len(dim_customer)+1))

    dim_route = df[["Route_ID","Origin_Region","Destination_Region","Distance_Category"]].drop_duplicates().copy()
    dim_route.insert(0, "Route_Key", range(1, len(dim_route)+1))

    dim_vehicle = df[["Vehicle_ID","Vehicle_Type","Capacity_KG","Fuel_Type"]].drop_duplicates().copy()
    dim_vehicle.insert(0, "Vehicle_Key", range(1, len(dim_vehicle)+1))

    dim_driver = df[["Driver_ID","Experience_Years","Performance_Rating"]].drop_duplicates().copy()
    dim_driver.insert(0, "Driver_Key", range(1, len(dim_driver)+1))

    dim_warehouse = df[["Warehouse_ID","Warehouse_Name","City_Warehouse","Region_Warehouse"]].drop_duplicates().copy()
    dim_warehouse.insert(0, "Warehouse_Key", range(1, len(dim_warehouse)+1))

    dim_location = df[["Latitude","Longitude","Origin_Region","Destination_Region"]].drop_duplicates().copy()
    dim_location.insert(0, "Location_Key", range(1, len(dim_location)+1))

    # Keys
    fact = df.copy()
    fact["Booking_Date_str"] = fact["Booking_Date"].astype(str)
    fact = fact.merge(dim_date[["Date_Key","Booking_Date"]], left_on="Booking_Date_str", right_on="Booking_Date", how="left")
    fact = fact.merge(dim_customer[["Customer_Key","Customer_ID"]], on="Customer_ID", how="left")
    fact = fact.merge(dim_route[["Route_Key","Route_ID"]], on="Route_ID", how="left")
    fact = fact.merge(dim_vehicle[["Vehicle_Key","Vehicle_ID"]], on="Vehicle_ID", how="left")
    fact = fact.merge(dim_driver[["Driver_Key","Driver_ID"]], on="Driver_ID", how="left")
    fact = fact.merge(dim_warehouse[["Warehouse_Key","Warehouse_ID"]], on="Warehouse_ID", how="left")
    fact = fact.merge(dim_location[["Location_Key","Latitude","Longitude","Origin_Region","Destination_Region"]],
                      on=["Latitude","Longitude","Origin_Region","Destination_Region"], how="left")

    fact_shipment = fact[[
        "Shipment_ID","Date_Key","Customer_Key","Route_Key","Vehicle_Key",
        "Driver_Key","Warehouse_Key","Location_Key","Distance_KM",
        "Actual_Delivery_Hours","Expected_Delivery_Hours","Delay_Hours",
        "Transportation_Cost","Delivery_Status"
    ]].copy()
    fact_shipment.insert(0, "Shipment_Key", range(1, len(fact_shipment)+1))
    fact_shipment.rename(columns={"Distance_KM":"Distance",
                                  "Actual_Delivery_Hours":"Delivery_Time",
                                  "Expected_Delivery_Hours":"Expected_Time"}, inplace=True)
    fact_shipment["Shipment_Count"] = 1

    for name, table in [
        ("Dim_Date",dim_date),("Dim_Customer",dim_customer),("Dim_Route",dim_route),
        ("Dim_Vehicle",dim_vehicle),("Dim_Driver",dim_driver),
        ("Dim_Warehouse",dim_warehouse),("Dim_Location",dim_location),
        ("Fact_Shipment",fact_shipment)
    ]:
        table.to_sql(name, con, if_exists="replace", index=False)

    con.execute("CREATE INDEX idx_fact_date ON Fact_Shipment(Date_Key)")
    con.execute("CREATE INDEX idx_fact_route ON Fact_Shipment(Route_Key)")
    con.commit()
    con.close()
    print("SQLite Star Schema warehouse created:", db)

def main():
    df = load_and_clean()
    build_sqlite_warehouse(df)

if __name__ == "__main__":
    main()
