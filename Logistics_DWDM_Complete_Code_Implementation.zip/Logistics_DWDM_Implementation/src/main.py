from generate_data import main as generate
from etl_warehouse import main as etl
from olap_analysis import main as olap
from analytics import main as analytics
from spatial_analysis import main as spatial

if __name__ == "__main__":
    print("\\nSTEP 1: GENERATING MULTI-SOURCE LOGISTICS DATA")
    generate()
    print("\\nSTEP 2: ETL AND DATA WAREHOUSE IMPLEMENTATION")
    etl()
    print("\\nSTEP 3: OLAP ANALYSIS")
    olap()
    print("\\nSTEP 4: CLASSIFICATION, CLUSTERING AND PATTERN MINING")
    analytics()
    print("\\nSTEP 5: SPATIAL ANALYTICS")
    spatial()
    print("\\nPROJECT IMPLEMENTATION COMPLETED SUCCESSFULLY.")
