from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.cluster import KMeans

BASE = Path(__file__).resolve().parents[1]
DATA = BASE/"data"/"processed"/"logistics_integrated.csv"
OUT = BASE/"outputs"/"results"
GRAPHS = BASE/"outputs"/"graphs"

def association_rules_custom(transactions, min_support=0.08, min_confidence=0.55):
    # Simple Apriori-style pair rules.
    n = len(transactions)
    items = sorted(set(x for t in transactions for x in t))
    support = {}
    for item in items:
        s = sum(item in t for t in transactions)/n
        support[(item,)] = s

    rules = []
    for a in items:
        for b in items:
            if a == b: 
                continue
            ab = sum(a in t and b in t for t in transactions)/n
            if ab >= min_support and support[(a,)] > 0:
                conf = ab/support[(a,)]
                if conf >= min_confidence:
                    lift = conf/support[(b,)] if support[(b,)] > 0 else 0
                    rules.append({
                        "Antecedent": a, "Consequent": b,
                        "Support": round(ab,4), "Confidence": round(conf,4), "Lift": round(lift,4)
                    })
    return pd.DataFrame(rules).sort_values(["Lift","Confidence"], ascending=False) if rules else pd.DataFrame()

def classification(df):
    OUT.mkdir(parents=True, exist_ok=True); GRAPHS.mkdir(parents=True, exist_ok=True)
    features = [
        "Distance_KM","Weight_KG","Traffic_Level","Weather_Condition",
        "Warehouse_Processing_Hours","Expected_Delivery_Hours",
        "Experience_Years","Vehicle_Type","Performance_Rating"
    ]
    X = df[features].copy()
    y = (df["Delivery_Status"] == "Delayed").astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X,y,test_size=0.2,random_state=42,stratify=y
    )

    numeric = ["Distance_KM","Weight_KG","Warehouse_Processing_Hours",
               "Expected_Delivery_Hours","Experience_Years","Performance_Rating"]
    categorical = ["Traffic_Level","Weather_Condition","Vehicle_Type"]

    pre = ColumnTransformer([
        ("num", StandardScaler(), numeric),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical)
    ])

    models = {
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42),
        "SVM": SVC(C=2.0, kernel="rbf", probability=False, random_state=42)
    }

    results = []
    for name, model in models.items():
        pipe = Pipeline([("pre",pre),("model",model)])
        pipe.fit(X_train,y_train)
        pred = pipe.predict(X_test)
        scores = cross_val_score(pipe, X, y, cv=10, scoring="f1")
        cm = confusion_matrix(y_test,pred)
        pd.DataFrame(cm, index=["Actual On-Time","Actual Delayed"],
                     columns=["Predicted On-Time","Predicted Delayed"]).to_csv(
                         OUT/f"confusion_matrix_{name.lower().replace(' ','_')}.csv"
                     )
        results.append([name,
                        accuracy_score(y_test,pred),
                        precision_score(y_test,pred,zero_division=0),
                        recall_score(y_test,pred,zero_division=0),
                        f1_score(y_test,pred,zero_division=0),
                        scores.mean()])

    # GaussianNB needs dense encoded features
    nb_pre = ColumnTransformer([
        ("num", StandardScaler(), numeric),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical)
    ])
    nb_pipe = Pipeline([("pre",nb_pre),("model",GaussianNB())])
    nb_pipe.fit(X_train,y_train)
    pred = nb_pipe.predict(X_test)
    scores = cross_val_score(nb_pipe, X, y, cv=10, scoring="f1")
    cm = confusion_matrix(y_test,pred)
    pd.DataFrame(cm, index=["Actual On-Time","Actual Delayed"],
                 columns=["Predicted On-Time","Predicted Delayed"]).to_csv(
                     OUT/"confusion_matrix_naive_bayes.csv"
                 )
    results.append(["Naive Bayes",
                    accuracy_score(y_test,pred),
                    precision_score(y_test,pred,zero_division=0),
                    recall_score(y_test,pred,zero_division=0),
                    f1_score(y_test,pred,zero_division=0),
                    scores.mean()])

    res = pd.DataFrame(results, columns=["Model","Accuracy","Precision","Recall","F1_Score","CV_F1_Mean"])
    res = res.sort_values("F1_Score", ascending=False)
    res.to_csv(OUT/"model_comparison.csv", index=False)

    plt.figure(figsize=(8,5))
    plt.bar(res["Model"], res["Accuracy"]*100)
    plt.title("Classification Model Comparison")
    plt.xlabel("Model"); plt.ylabel("Accuracy (%)")
    plt.tight_layout()
    plt.savefig(GRAPHS/"model_comparison.png", dpi=180)
    plt.close()
    return res

def clustering(df):
    route = df.groupby("Route_ID").agg(
        Distance_KM=("Distance_KM","mean"),
        Travel_Time=("Actual_Delivery_Hours","mean"),
        Delay_Hours=("Delay_Hours","mean"),
        Average_Speed_KMPH=("Average_Speed_KMPH","mean")
    ).reset_index()

    X = StandardScaler().fit_transform(route[["Distance_KM","Travel_Time","Delay_Hours","Average_Speed_KMPH"]])
    km = KMeans(n_clusters=3, random_state=42, n_init=20)
    route["Cluster"] = km.fit_predict(X)

    # Meaningful labels based on average delay within cluster
    means = route.groupby("Cluster")["Delay_Hours"].mean().sort_values()
    labels = {means.index[0]:"Efficient Route", means.index[1]:"Moderate-Risk Route", means.index[2]:"High-Risk Route"}
    route["Cluster_Label"] = route["Cluster"].map(labels)
    route.to_csv(OUT/"route_clusters.csv", index=False)

    plt.figure(figsize=(8,5))
    for c in sorted(route["Cluster"].unique()):
        part = route[route["Cluster"]==c]
        plt.scatter(part["Distance_KM"], part["Travel_Time"], label=labels[c])
    plt.title("Route Clustering")
    plt.xlabel("Average Distance (KM)")
    plt.ylabel("Average Delivery Time (Hours)")
    plt.legend(); plt.tight_layout()
    plt.savefig(GRAPHS/"route_clusters.png", dpi=180)
    plt.close()
    return route

def patterns(df):
    # Each shipment transaction is represented by route, vehicle and distance category.
    tx = []
    for _,r in df.iterrows():
        tx.append({
            "Route="+str(r["Route_ID"]),
            "Vehicle="+str(r["Vehicle_Type"]),
            "Distance="+str(r["Distance_Category"]),
            "Traffic="+str(r["Traffic_Level"])
        })
    rules = association_rules_custom(tx)
    rules.to_csv(OUT/"association_rules.csv", index=False)
    return rules

def main():
    df = pd.read_csv(DATA)
    results = classification(df)
    clusters = clustering(df)
    rules = patterns(df)
    print("\\nModel Comparison:\\n", results.to_string(index=False))
    print("\\nRoute Clusters:\\n", clusters.head().to_string(index=False))
    print("\\nTop Association Rules:\\n", rules.head(10).to_string(index=False) if not rules.empty else "No rules found")

if __name__ == "__main__":
    main()
