import numpy as np
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
RAW = BASE / "data" / "raw"

def main(n=2500, seed=42):
    rng = np.random.default_rng(seed)
    RAW.mkdir(parents=True, exist_ok=True)

    regions = ["North", "South", "East", "West"]
    cities = {
        "North": ["Delhi", "Jaipur", "Chandigarh"],
        "South": ["Chennai", "Bengaluru", "Hyderabad"],
        "East": ["Kolkata", "Bhubaneswar", "Guwahati"],
        "West": ["Mumbai", "Pune", "Ahmedabad"]
    }
    vehicle_types = ["Truck", "Van", "Mini Truck"]
    weather_types = ["Clear", "Rain", "Storm"]
    traffic_types = ["Low", "Medium", "High"]

    customers = pd.DataFrame({
        "Customer_ID": [f"C{i:04d}" for i in range(1, 401)],
        "Customer_Type": rng.choice(["Retail", "Business", "Enterprise"], 400, p=[.5,.35,.15]),
        "Region": rng.choice(regions, 400),
    })
    customers["City"] = customers["Region"].map(lambda r: rng.choice(cities[r]))
    customers.to_csv(RAW/"customers.csv", index=False)

    vehicles = pd.DataFrame({
        "Vehicle_ID": [f"V{i:03d}" for i in range(1, 81)],
        "Vehicle_Type": rng.choice(vehicle_types, 80, p=[.45,.35,.20]),
        "Capacity_KG": rng.integers(500, 10000, 80),
        "Fuel_Type": rng.choice(["Diesel", "CNG", "Electric"], 80, p=[.7,.2,.1])
    })
    vehicles.to_csv(RAW/"vehicles.csv", index=False)

    drivers = pd.DataFrame({
        "Driver_ID": [f"D{i:03d}" for i in range(1, 121)],
        "Experience_Years": rng.integers(1, 21, 120),
        "Performance_Rating": np.round(rng.uniform(2.5, 5.0, 120), 2)
    })
    drivers.to_csv(RAW/"drivers.csv", index=False)

    warehouses = pd.DataFrame({
        "Warehouse_ID": [f"W{i:02d}" for i in range(1, 13)],
        "Warehouse_Name": [f"Logistics Hub {i}" for i in range(1, 13)],
        "Region": rng.choice(regions, 12)
    })
    warehouses["City"] = warehouses["Region"].map(lambda r: rng.choice(cities[r]))
    warehouses.to_csv(RAW/"warehouses.csv", index=False)

    start = pd.Timestamp("2025-01-01")
    booking = start + pd.to_timedelta(rng.integers(0, 730, n), unit="D")
    distance = rng.uniform(20, 1500, n).round(1)
    weight = rng.uniform(.2, 800, n).round(2)
    traffic = rng.choice(traffic_types, n, p=[.3,.45,.25])
    weather = rng.choice(weather_types, n, p=[.65,.27,.08])
    driver_exp = rng.integers(1, 21, n)
    warehouse_hours = rng.uniform(0.5, 10, n).round(2)
    expected_hours = (distance / 55 + warehouse_hours + rng.normal(0, 2, n)).clip(4, 100)

    # Delay probability is intentionally related to realistic operational features.
    risk = (
        0.0022 * distance +
        np.where(traffic == "High", 1.2, np.where(traffic == "Medium", .45, 0)) +
        np.where(weather == "Storm", 1.6, np.where(weather == "Rain", .55, 0)) +
        0.10 * warehouse_hours -
        0.07 * driver_exp +
        rng.normal(0, 1.0, n)
    )
    p_delay = 1/(1+np.exp(-(risk-2.0)))
    delayed = rng.random(n) < p_delay
    delay_hours = np.where(delayed, rng.gamma(2.0, 3.5, n), 0).round(2)
    actual_hours = (expected_hours + delay_hours + rng.normal(0, 1.0, n)).clip(1, 150).round(2)

    origin_region = rng.choice(regions, n)
    destination_region = rng.choice(regions, n)
    destination_region = np.where(destination_region == origin_region,
                                  rng.choice(regions, n), destination_region)

    shipment = pd.DataFrame({
        "Shipment_ID": [f"S{i:06d}" for i in range(1, n+1)],
        "Customer_ID": rng.choice(customers["Customer_ID"], n),
        "Vehicle_ID": rng.choice(vehicles["Vehicle_ID"], n),
        "Driver_ID": rng.choice(drivers["Driver_ID"], n),
        "Warehouse_ID": rng.choice(warehouses["Warehouse_ID"], n),
        "Booking_Date": booking,
        "Origin_Region": origin_region,
        "Destination_Region": destination_region,
        "Distance_KM": distance,
        "Weight_KG": weight,
        "Traffic_Level": traffic,
        "Weather_Condition": weather,
        "Warehouse_Processing_Hours": warehouse_hours,
        "Expected_Delivery_Hours": expected_hours.round(2),
        "Actual_Delivery_Hours": actual_hours,
        "Delay_Hours": delay_hours,
        "Delivery_Status": np.where(delayed, "Delayed", "On-Time"),
        "Transportation_Cost": (distance * rng.uniform(8, 15, n) + weight*rng.uniform(.5, 2, n)).round(2)
    })

    # Intentionally add a few missing values and duplicates to demonstrate ETL.
    shipment.loc[rng.choice(n, 30, replace=False), "Distance_KM"] = np.nan
    shipment.loc[rng.choice(n, 25, replace=False), "Weight_KG"] = np.nan
    shipment.loc[rng.choice(n, 20, replace=False), "Traffic_Level"] = np.nan
    shipment.loc[rng.choice(n, 15, replace=False), "Weather_Condition"] = np.nan
    duplicates = shipment.sample(20, random_state=seed)
    shipment = pd.concat([shipment, duplicates], ignore_index=True)
    shipment.to_csv(RAW/"shipments.csv", index=False)

    # GPS source
    gps = pd.DataFrame({
        "Shipment_ID": shipment["Shipment_ID"],
        "Latitude": rng.uniform(8.0, 35.0, len(shipment)).round(6),
        "Longitude": rng.uniform(68.0, 89.0, len(shipment)).round(6),
        "Average_Speed_KMPH": rng.uniform(25, 75, len(shipment)).round(2)
    })
    gps.to_csv(RAW/"gps.csv", index=False)

    print("Raw data generated successfully.")
    print("Shipment records including intentional duplicates:", len(shipment))

if __name__ == "__main__":
    main()
